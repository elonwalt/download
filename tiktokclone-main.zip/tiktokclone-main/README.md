# tiktokclone
Tiktok clone project

Static cloning of tiktok app using vanilla HTML CSS JS and JQUERY
